export const reloadApp = async () => device.reloadReactNative()
